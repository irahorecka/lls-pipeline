#! /usr/bin/env python

from __future__ import absolute_import

from aksetup_helper import configure_frontend
configure_frontend()
